<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
    <head>
        <title>遇聊-陌生人聊天室</title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <link type="text/css" rel="stylesheet" href="style.css">
		<meta name="Description" content="是一个匿名的陌生人随机聊天网站，进入网站，你可以马上跟一个互不认识的陌生人聊天。通过文字逐渐相互了解。尽情享受这种从陌生人到朋友的感觉吧。" />
		<meta name="Keywords" content="匿名聊天,陌生人聊天,在线聊天,Omegle,山寨Omegle,国内Omegle,中国Omegle" />
		<meta name="Author" content="Longbill" />
        <script src="jquery.js"></script>
        <script>
        function init_window()
        {
        	$('#main').height($(window).height()-$('#header').height());
        	$('#content').width($('#chat_window').width()-$('#disconnectwrapper').width()*2-6);
        	
			var space = 50;
			if (navigator.userAgent.match(/msie\s7/i)) space = 50;
			if (navigator.userAgent.match(/msie\s6/i)) space = 50;
	
        	$('#chat_window').height($(window).height()-$('#header').height()-$('#content').height()-space);
        }
        init_window();
        window.onresize = init_window;
        var lang = 
        {
        	send_error:'发送失败',
        	bye:'Bye!',
        	online_num:'在线人数：',
        	waiting:'等待陌生人连接...',
        	me:'<span style="color:#333">我：</span>',
        	stranger:'<span style="color:#333">陌生人：</span>',
        	connected:'<span style="color:orange">连接成功，快跟对方打个招呼吧！</span>对方可能来自：',
        	disconnected:'对方已断开。',
        	typing:'<span style="font-size:12px;color:#999">对方正在输入文字</span>',
        	reconnect:'重新连接',
        	download:'下载聊天记录',
        	logining:'登录中..',
        	logined:'登录成功',
        	you_disconnect:'您已经断开',
        	contact_me:'&nbsp;<a href="http://item.taobao.com/item.htm?spm=686.1000925.1000774.37.X5QuKN&id=37036719581" target="_blank">免费网络电话，终身免费使用。全国手机都可拨打。</a>',
			new_msg:'新消息来啦！',
            NNN:'<font color="red">算命网站...</font>'
        };
        var ajax_delay = 1000; //ms
        </script>
        <script src="chat.js"></script>
    <style type="text/css">
<!--
body {
	background-color: #FFFBF0;
	background-image: url(images/event.jpg);
}
a:link {
	color: #FF0000;
	text-decoration: none;
}
a:visited {
	text-decoration: none;
	color: #FF9966;
}
a:hover {
	text-decoration: none;
}
a:active {
	text-decoration: none;
	color: #FF6600;
}
.STYLE1 {font-size: x-small}
.STYLE4 {
	color: #0066CC;
	font-size: small;
}
.STYLE5 {
	color: #0066CC
}
.STYLE10 {color: #FF9900}
-->
    </style></head>
    <body scroll="no">
        <div id="header">
        	<div id="header_content">
        		<table cellpadding="0" cellspacing="0" border="0">
        			<tr>
        				<td background="images/tou.jpg">&nbsp;</td>
       				  <td background="images/tou.jpg"><img src="images/logo.png" width="300" height="80"></td>
		  <td valign="middle" background="images/tou.jpg" style="text-align:right">
    	       				<span class="STYLE10">当前用户:<?php session_start(); echo $_SESSION["userid"];?>&nbsp;&nbsp;<a href="/?logout=u">logout</a></span> | 在线人数：0    	       			</td>
   	       		  </tr>
    	       	</table>
    	    </div>
        </div> 
        <div id="main">
            <?php
            error_reporting(E_ALL^E_NOTICE);
            session_start();
            $cc= date('y-m-d');
            if(isset($_GET['logout'])){
                unset($_SESSION["userid"]);
            }
            if(isset($_SESSION["userid"])==false){
                if(empty($_POST["fuserid"])==true){
                    echo '<div> 用户名：<form action="index.php" name="reply"id="reply" method="post"><input type="text" id="fuserid" name="fuserid"/> <br />';
                    echo '<div> <input type="submit" value="submit"/></form> ';
                }else{
                    $_SESSION["userid"]=$_POST["fuserid"];
                    header("Location: http://localhost/chat.php?room=a");
                }
            }else{
            header("Location: http://localhost/chat.php?room=a");
            exit;
            ?>
            <h1></h1>
        	<div id="description">
        		<div style="width:700px;margin:0 auto;text-align:center;">
        		  <div style="height:500px;float:left; width:380px;">
   			      <img src="images/taibei.png" width="320" height="400" />	        		</div>
        		  <div style="height:500px;float:left; width:230px;">
        			  <div style="margin-top:70px;">
        			    <p>&nbsp;</p>
	        			  <p>&nbsp;</p>
	        			  <p>&nbsp;</p>
        			</div>
	        			<div style="margin:20px 0;margin-bottom:40px;">
	        				<a href="javascript:init_chat();"><img src="images/start.png" width="183" height="70" /></a>	        			</div>
	        			
        		  </div>
        		</div>
        		<div id="announcement">
        		  <p>
        		    <script type="text/javascript">var _bdhmProtocol = (("https:" == document.location.protocol) ? " https://" : " http://");
document.write(unescape("%3Cscript src='" + _bdhmProtocol + "hm.baidu.com/h.js%3F97080db2d03416d746b0ecaea4cbe397' type='text/javascript'%3E%3C/script%3E"));
</script>
</p>
        		  <p class="STYLE1 STYLE4 STYLE5"><a href="http://www.woaiyl.com/xvo.html">随机文字聊天</a> |　<a href="http://www.woaiyl.com/xvo.html">随机聊天视频版</a></p>
       		  </div>
       	  </div>
        	<div id="chat" style="display:none">
        		<div id="chat_window">
	 			</div>
        		<div id="chat_bottom">
        			<div id="disconnectwrapper" onclick="disconnect()">
        				断开
        			</div>
	        			<textarea id="content" ></textarea>
        			<div id="sendwrapper" onclick="send_bt()" >
        				发送
        			</div>
        		</div>
        	</div>
        </div>
    
<map name="logoMap">
<area shape="poly" coords="91,4" href="#"><area shape="poly" coords="194,32" href="#"><area shape="poly" coords="142,36" href="#">
</map>
        <?php  }?>

    </body>
</html>