<?php die();?>
1422714511|<span style='color:#16a5e9;'>Welcome to Longbill's Mini AJAX Chatroom!</span>
1422714603|ffee:afsddsfasf
1422714627|ffee:<span style='font-family:黑体;'>faa</span>
1422714634|ffee:<span style='font-family:黑体;color:#000000;'>fee</span>
1422714641|ffee:<span style='font-family:黑体;font-weight:bold;color:#000000;'>faa</span>
1422714771|wo:お願いします
1422714785|wo１１:あえ
1422714795|ffee:soudesu
1422715925|wo１１:だsd
1422715940|ffee:www
1422715943|wo１１:２２２
1422716171|周旭东:dasdaa
1422716191|ｖｖｖ:あｓｄさｄ
1422716319|ｖｖｖ:だｓｄ
