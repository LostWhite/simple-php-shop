<?php die();?>
1422721782|<span style='color:#16a5e9;'>Welcome to Longbill's Mini AJAX Chatroom!</span>
1422721786|周旭东:122
1422721807|周旭东:有人吗
1422721881|周旭东:111
1422721923|周旭东:rr
1422792924|www:ddwdwd213
1422792995|www:aseffsse