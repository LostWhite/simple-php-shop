<?php die();?>
1422720001|<span style='color:#16a5e9;'>Welcome to Longbill's Mini AJAX Chatroom!</span>
